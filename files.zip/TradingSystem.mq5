//+------------------------------------------------------------------+
//|                                              TradingSystem.mq5   |
//|                          Multi-Strategy Automated Trading System |
//+------------------------------------------------------------------+
#property copyright "Trading System"
#property version   "1.00"
#property strict

#include <Trade\Trade.mqh>
#include <Trade\PositionInfo.mqh>
#include <Trade\OrderInfo.mqh>

CTrade         trade;
CPositionInfo  posInfo;
COrderInfo     orderInfo;

//--- Input Parameters: Risk Management
input group "=== RISK MANAGEMENT ==="
input double   RiskPercent        = 1.5;    // Risk % per trade
input double   FixedLotSize       = 0.01;   // Fixed lot size (if UseFixedLot = true)
input bool     UseFixedLot        = false;  // Use fixed lot instead of % risk
input double   MaxDailyLossPercent= 3.0;    // Max daily loss %
input double   DefaultSL_Pips     = 30.0;   // Default stop loss (pips)
input double   DefaultTP_Pips     = 60.0;   // Default take profit (pips)
input double   TrailingStop_Pips  = 15.0;   // Trailing stop (pips, 0 = disabled)

//--- Input Parameters: Strategies
input group "=== STRATEGY SELECTION ==="
input bool     UseBreakout        = true;   // Enable Breakout strategy
input bool     UseSMC             = true;   // Enable SMC strategy
input bool     UsePatterns        = true;   // Enable Chart Patterns strategy

//--- Breakout Settings
input group "=== BREAKOUT SETTINGS ==="
input int      BreakoutLookback   = 20;     // Candles to look back for H/L
input double   BreakoutBuffer_Pips= 2.0;    // Buffer above/below breakout level

//--- SMC Settings
input group "=== SMC SETTINGS ==="
input int      SMC_SwingLookback  = 10;     // Swing high/low lookback
input int      SMC_FVG_Threshold  = 3;      // Min FVG size in pips

//--- Pattern Settings
input group "=== PATTERN SETTINGS ==="
input int      PatternLookback    = 5;      // Candles for pattern detection

//--- General Settings
input group "=== GENERAL SETTINGS ==="
input int      MagicNumber        = 123456; // EA magic number
input int      MaxOpenTrades      = 3;      // Max simultaneous trades
input bool     TradeOnNewBar      = true;   // Trade only on new bar
input ENUM_TIMEFRAMES Timeframe   = PERIOD_H1; // Trading timeframe
input string   AllowedPairs       = "";     // Allowed pairs (blank = current only)

//--- Global Variables
double   g_startDayBalance   = 0;
double   g_dailyLoss         = 0;
datetime g_lastBarTime       = 0;
double   g_point;
int      g_digits;

//+------------------------------------------------------------------+
//| Expert initialization                                            |
//+------------------------------------------------------------------+
int OnInit()
{
   trade.SetExpertMagicNumber(MagicNumber);
   trade.SetDeviationInPoints(10);
   trade.SetTypeFilling(ORDER_FILLING_IOC);

   g_point  = _Point;
   g_digits = _Digits;

   if(_Digits == 3 || _Digits == 5) g_point *= 10;

   g_startDayBalance = AccountInfoDouble(ACCOUNT_BALANCE);
   Print("=== Trading System Initialized ===");
   Print("Risk%: ", RiskPercent, " | MaxDailyLoss%: ", MaxDailyLossPercent);
   Print("Strategies: Breakout=", UseBreakout, " SMC=", UseSMC, " Patterns=", UsePatterns);

   return(INIT_SUCCEEDED);
}

//+------------------------------------------------------------------+
//| Expert tick function                                             |
//+------------------------------------------------------------------+
void OnTick()
{
   //--- New day reset
   MqlDateTime dt;
   TimeToStruct(TimeCurrent(), dt);
   static int lastDay = -1;
   if(dt.day != lastDay)
   {
      g_startDayBalance = AccountInfoDouble(ACCOUNT_BALANCE);
      g_dailyLoss       = 0;
      lastDay           = dt.day;
   }

   //--- Check daily loss limit
   if(IsDailyLossBreached()) return;

   //--- New bar check
   if(TradeOnNewBar)
   {
      datetime currentBar = iTime(_Symbol, Timeframe, 0);
      if(currentBar == g_lastBarTime) return;
      g_lastBarTime = currentBar;
   }

   //--- Trailing stop management
   ManageTrailingStop();

   //--- Max trades check
   if(CountOpenTrades() >= MaxOpenTrades) return;

   //--- Run strategies
   if(UseBreakout) CheckBreakoutStrategy();
   if(UseSMC)      CheckSMCStrategy();
   if(UsePatterns) CheckPatternStrategy();
}

//+------------------------------------------------------------------+
//| STRATEGY 1: Breakout                                             |
//+------------------------------------------------------------------+
void CheckBreakoutStrategy()
{
   double highestHigh = 0, lowestLow = DBL_MAX;

   for(int i = 1; i <= BreakoutLookback; i++)
   {
      double h = iHigh(_Symbol, Timeframe, i);
      double l = iLow(_Symbol, Timeframe, i);
      if(h > highestHigh) highestHigh = h;
      if(l < lowestLow)   lowestLow   = l;
   }

   double currentClose = iClose(_Symbol, Timeframe, 0);
   double buffer       = BreakoutBuffer_Pips * g_point;

   double sl, tp;

   //--- Bullish breakout
   if(currentClose > highestHigh + buffer && !HasOpenTrade(ORDER_TYPE_BUY))
   {
      sl = currentClose - DefaultSL_Pips * g_point;
      tp = currentClose + DefaultTP_Pips * g_point;
      double lot = CalculateLotSize(MathAbs(currentClose - sl));
      if(lot > 0)
      {
         Print("[Breakout] BUY signal at ", currentClose, " SL=", sl, " TP=", tp);
         trade.Buy(lot, _Symbol, 0, sl, tp, "Breakout BUY");
      }
   }

   //--- Bearish breakout
   if(currentClose < lowestLow - buffer && !HasOpenTrade(ORDER_TYPE_SELL))
   {
      sl = currentClose + DefaultSL_Pips * g_point;
      tp = currentClose - DefaultTP_Pips * g_point;
      double lot = CalculateLotSize(MathAbs(currentClose - sl));
      if(lot > 0)
      {
         Print("[Breakout] SELL signal at ", currentClose, " SL=", sl, " TP=", tp);
         trade.Sell(lot, _Symbol, 0, sl, tp, "Breakout SELL");
      }
   }
}

//+------------------------------------------------------------------+
//| STRATEGY 2: Smart Money Concepts (SMC)                          |
//| - Order Blocks, Fair Value Gaps, Break of Structure             |
//+------------------------------------------------------------------+
void CheckSMCStrategy()
{
   //--- Detect Break of Structure (BOS)
   double swingHigh = 0, swingLow = DBL_MAX;
   int    swingHighBar = -1, swingLowBar = -1;

   for(int i = 2; i <= SMC_SwingLookback; i++)
   {
      double h = iHigh(_Symbol, Timeframe, i);
      double l = iLow(_Symbol, Timeframe, i);
      if(h > swingHigh) { swingHigh = h; swingHighBar = i; }
      if(l < swingLow)  { swingLow  = l; swingLowBar  = i; }
   }

   double currentHigh  = iHigh(_Symbol, Timeframe, 1);
   double currentLow   = iLow(_Symbol, Timeframe, 1);
   double currentClose = iClose(_Symbol, Timeframe, 1);

   //--- BOS to upside — look for order block below
   if(currentHigh > swingHigh && !HasOpenTrade(ORDER_TYPE_BUY))
   {
      //--- Find bullish order block (last bearish candle before impulse)
      double obHigh = iHigh(_Symbol, Timeframe, swingHighBar + 1);
      double obLow  = iLow(_Symbol, Timeframe, swingHighBar + 1);

      //--- Check for Fair Value Gap
      double fvgHigh = iLow(_Symbol, Timeframe, swingHighBar - 1);
      double fvgLow  = iHigh(_Symbol, Timeframe, swingHighBar + 1);
      bool   hasFVG  = (fvgHigh - fvgLow) > (SMC_FVG_Threshold * g_point);

      double ask = SymbolInfoDouble(_Symbol, SYMBOL_ASK);
      double sl  = obLow - (2 * g_point);
      double tp  = ask + DefaultTP_Pips * g_point;

      if(hasFVG && ask >= obLow && ask <= obHigh)
      {
         double lot = CalculateLotSize(MathAbs(ask - sl));
         if(lot > 0)
         {
            Print("[SMC] BUY Order Block entry at ", ask, " OB: ", obLow, "-", obHigh, " FVG=", hasFVG);
            trade.Buy(lot, _Symbol, 0, sl, tp, "SMC BUY");
         }
      }
   }

   //--- BOS to downside
   if(currentLow < swingLow && !HasOpenTrade(ORDER_TYPE_SELL))
   {
      double obHigh = iHigh(_Symbol, Timeframe, swingLowBar + 1);
      double obLow  = iLow(_Symbol, Timeframe, swingLowBar + 1);

      double fvgHigh = iLow(_Symbol, Timeframe, swingLowBar - 1);
      double fvgLow  = iHigh(_Symbol, Timeframe, swingLowBar + 1);
      bool   hasFVG  = (fvgHigh - fvgLow) > (SMC_FVG_Threshold * g_point);

      double bid = SymbolInfoDouble(_Symbol, SYMBOL_BID);
      double sl  = obHigh + (2 * g_point);
      double tp  = bid - DefaultTP_Pips * g_point;

      if(hasFVG && bid <= obHigh && bid >= obLow)
      {
         double lot = CalculateLotSize(MathAbs(bid - sl));
         if(lot > 0)
         {
            Print("[SMC] SELL Order Block entry at ", bid, " OB: ", obLow, "-", obHigh, " FVG=", hasFVG);
            trade.Sell(lot, _Symbol, 0, sl, tp, "SMC SELL");
         }
      }
   }
}

//+------------------------------------------------------------------+
//| STRATEGY 3: Chart Patterns                                      |
//| - Double Top/Bottom, Pin Bar, Engulfing                         |
//+------------------------------------------------------------------+
void CheckPatternStrategy()
{
   double o1 = iOpen(_Symbol, Timeframe, 1),  c1 = iClose(_Symbol, Timeframe, 1);
   double h1 = iHigh(_Symbol, Timeframe, 1),  l1 = iLow(_Symbol, Timeframe, 1);
   double o2 = iOpen(_Symbol, Timeframe, 2),  c2 = iClose(_Symbol, Timeframe, 2);
   double h2 = iHigh(_Symbol, Timeframe, 2),  l2 = iLow(_Symbol, Timeframe, 2);

   double bodySize1  = MathAbs(c1 - o1);
   double totalSize1 = h1 - l1;
   double upperWick1 = h1 - MathMax(o1, c1);
   double lowerWick1 = MathMin(o1, c1) - l1;

   //--- Bullish Pin Bar
   bool bullishPinBar = (lowerWick1 > bodySize1 * 2.0) &&
                        (lowerWick1 > upperWick1 * 3.0) &&
                        (c1 > o1);

   //--- Bearish Pin Bar
   bool bearishPinBar = (upperWick1 > bodySize1 * 2.0) &&
                        (upperWick1 > lowerWick1 * 3.0) &&
                        (c1 < o1);

   //--- Bullish Engulfing
   bool bullishEngulf = (c1 > o1) && (c2 < o2) &&
                        (c1 > o2) && (o1 < c2);

   //--- Bearish Engulfing
   bool bearishEngulf = (c1 < o1) && (c2 > o2) &&
                        (c1 < o2) && (o1 > c2);

   //--- Double Bottom (simplified)
   double low1 = iLow(_Symbol, Timeframe, 1);
   double low3 = iLow(_Symbol, Timeframe, 3);
   double low5 = iLow(_Symbol, Timeframe, 5);
   bool doubleBottom = (MathAbs(low1 - low3) < 5 * g_point) &&
                       (iHigh(_Symbol, Timeframe, 2) > iHigh(_Symbol, Timeframe, 4));

   //--- Double Top (simplified)
   double hi1 = iHigh(_Symbol, Timeframe, 1);
   double hi3 = iHigh(_Symbol, Timeframe, 3);
   bool doubleTop = (MathAbs(hi1 - hi3) < 5 * g_point) &&
                    (iLow(_Symbol, Timeframe, 2) < iLow(_Symbol, Timeframe, 4));

   double sl, tp, lot;
   double ask = SymbolInfoDouble(_Symbol, SYMBOL_ASK);
   double bid = SymbolInfoDouble(_Symbol, SYMBOL_BID);

   //--- BUY signals
   if((bullishPinBar || bullishEngulf || doubleBottom) && !HasOpenTrade(ORDER_TYPE_BUY))
   {
      sl  = l1 - (2 * g_point);
      tp  = ask + DefaultTP_Pips * g_point;
      lot = CalculateLotSize(MathAbs(ask - sl));
      if(lot > 0)
      {
         string pat = bullishPinBar ? "Pin Bar" : (bullishEngulf ? "Engulfing" : "Double Bottom");
         Print("[Pattern] BUY ", pat, " at ", ask);
         trade.Buy(lot, _Symbol, 0, sl, tp, "Pattern BUY: " + pat);
      }
   }

   //--- SELL signals
   if((bearishPinBar || bearishEngulf || doubleTop) && !HasOpenTrade(ORDER_TYPE_SELL))
   {
      sl  = h1 + (2 * g_point);
      tp  = bid - DefaultTP_Pips * g_point;
      lot = CalculateLotSize(MathAbs(bid - sl));
      if(lot > 0)
      {
         string pat = bearishPinBar ? "Pin Bar" : (bearishEngulf ? "Engulfing" : "Double Top");
         Print("[Pattern] SELL ", pat, " at ", bid);
         trade.Sell(lot, _Symbol, 0, sl, tp, "Pattern SELL: " + pat);
      }
   }
}

//+------------------------------------------------------------------+
//| Risk Management: Calculate lot size                              |
//+------------------------------------------------------------------+
double CalculateLotSize(double slDistance)
{
   if(UseFixedLot) return NormalizeLot(FixedLotSize);

   double balance    = AccountInfoDouble(ACCOUNT_BALANCE);
   double riskAmount = balance * (RiskPercent / 100.0);
   double tickValue  = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_VALUE);
   double tickSize   = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_SIZE);

   if(slDistance <= 0 || tickValue <= 0 || tickSize <= 0) return 0;

   double lot = riskAmount / ((slDistance / tickSize) * tickValue);
   return NormalizeLot(lot);
}

double NormalizeLot(double lot)
{
   double minLot  = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MIN);
   double maxLot  = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MAX);
   double lotStep = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_STEP);

   lot = MathFloor(lot / lotStep) * lotStep;
   lot = MathMax(minLot, MathMin(maxLot, lot));
   return NormalizeDouble(lot, 2);
}

//+------------------------------------------------------------------+
//| Trailing Stop Management                                         |
//+------------------------------------------------------------------+
void ManageTrailingStop()
{
   if(TrailingStop_Pips <= 0) return;
   double trailDist = TrailingStop_Pips * g_point;

   for(int i = PositionsTotal() - 1; i >= 0; i--)
   {
      if(!posInfo.SelectByIndex(i)) continue;
      if(posInfo.Magic() != MagicNumber || posInfo.Symbol() != _Symbol) continue;

      double sl     = posInfo.StopLoss();
      double price  = posInfo.PriceOpen();
      double profit = posInfo.Profit();
      ulong  ticket = posInfo.Ticket();

      if(posInfo.PositionType() == POSITION_TYPE_BUY)
      {
         double bid    = SymbolInfoDouble(_Symbol, SYMBOL_BID);
         double newSL  = bid - trailDist;
         if(newSL > sl + g_point)
            trade.PositionModify(ticket, newSL, posInfo.TakeProfit());
      }
      else if(posInfo.PositionType() == POSITION_TYPE_SELL)
      {
         double ask   = SymbolInfoDouble(_Symbol, SYMBOL_ASK);
         double newSL = ask + trailDist;
         if(sl == 0 || newSL < sl - g_point)
            trade.PositionModify(ticket, newSL, posInfo.TakeProfit());
      }
   }
}

//+------------------------------------------------------------------+
//| Daily Loss Check                                                 |
//+------------------------------------------------------------------+
bool IsDailyLossBreached()
{
   double balance     = AccountInfoDouble(ACCOUNT_BALANCE);
   double equity      = AccountInfoDouble(ACCOUNT_EQUITY);
   double maxLossAmt  = g_startDayBalance * (MaxDailyLossPercent / 100.0);
   double currentLoss = g_startDayBalance - equity;

   if(currentLoss >= maxLossAmt)
   {
      static bool warned = false;
      if(!warned) { Print("!!! Daily loss limit reached. Trading halted for today."); warned = true; }
      return true;
   }
   return false;
}

//+------------------------------------------------------------------+
//| Count open trades by magic                                       |
//+------------------------------------------------------------------+
int CountOpenTrades()
{
   int count = 0;
   for(int i = 0; i < PositionsTotal(); i++)
   {
      if(posInfo.SelectByIndex(i))
         if(posInfo.Magic() == MagicNumber && posInfo.Symbol() == _Symbol)
            count++;
   }
   return count;
}

//+------------------------------------------------------------------+
//| Check if trade direction already open                            |
//+------------------------------------------------------------------+
bool HasOpenTrade(ENUM_ORDER_TYPE dir)
{
   for(int i = 0; i < PositionsTotal(); i++)
   {
      if(!posInfo.SelectByIndex(i)) continue;
      if(posInfo.Magic() != MagicNumber || posInfo.Symbol() != _Symbol) continue;
      if(dir == ORDER_TYPE_BUY  && posInfo.PositionType() == POSITION_TYPE_BUY)  return true;
      if(dir == ORDER_TYPE_SELL && posInfo.PositionType() == POSITION_TYPE_SELL) return true;
   }
   return false;
}

//+------------------------------------------------------------------+
//| Close all positions                                              |
//+------------------------------------------------------------------+
void CloseAllPositions()
{
   for(int i = PositionsTotal() - 1; i >= 0; i--)
   {
      if(posInfo.SelectByIndex(i))
         if(posInfo.Magic() == MagicNumber)
            trade.PositionClose(posInfo.Ticket());
   }
}

//+------------------------------------------------------------------+
//| EA Deinitialization                                              |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
{
   Print("Trading System deinitialized. Reason: ", reason);
}
